export const colors = {
  orange: '#e57b3a',
  grey: '#b9c0bd',
  brown: '#c2b9af',
  black: '#000000',
};

// import React from 'react';
// import { shallow } from 'enzyme';

// import AppConnectCard from '../index';

describe('<AppConnectCard />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});

import background2 from '../../images/background2.jpg';
import background4 from '../../images/background4.jpg';
import background5 from '../../images/background5.jpg';
import background6 from '../../images/background6.jpg';
import background7 from '../../images/background7.jpg';

// const rand = Math.floor(Math.random() * 7);

// const backList = [
//   background2,
//   background4,
//   background5,
//   background6,
//   background7,
// ];

export default background6;
